package Learnacademy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Courses {
public WebDriver driver;

private By authordropdown=By.xpath("//div[2]//button[@data-toggle='dropdown']");
private By authorlist=By.xpath("//div[2]//ul[@class='dropdown-menu']");

Courses(WebDriver driver){
this.driver=driver;	
}

public WebElement verifyauthor() {
	return driver.findElement(authordropdown);
}
public WebElement verifyauthorlist() {
	WebElement list = null;
	List<WebElement> author=driver.findElements(authorlist);
	for (int i=0;i<author.size();i++) {
		 list=author.get(i);
	}
	return list;

}

}
