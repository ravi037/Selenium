package Learnacademy;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mysql.jdbc.Driver;

import Resources.Initialization;

public class Database extends Initialization  {
public WebDriver driver;



 private By popup=By.xpath("//button[text()='NO THANKS']");
 private By user=By.id("user_email");
 private By pwd=By.id("user_password");
	
 private By loginbtn=By.xpath("//span[text()='Login']");
 private By submitbtn=By.cssSelector("input[type='submit']");
	
	private String host="localhost";
	private String port="3306";	//3306

	public Database(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	public List<WebElement> popupsize() {
		return driver.findElements(popup);
		
	}
	public WebElement getpopup() {
		return driver.findElement(popup);
	}
	public WebDriver launchqaacademy() {
		 System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("http://qaclickacademy.com/");
			return driver;
	 } 
			public void handlepopup() {
				
		WebDriverWait wait =new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(popup));
		if(popupsize().size()>0) {
			getpopup().click();
		}
}
	public WebElement logindbdata() {
		return driver.findElement(loginbtn);
	}
public void dbdata() throws SQLException, InterruptedException, IOException, ClassNotFoundException {
	// load and register JDBC driver for MySQL 
	// Class.forName("com.mysql.jdbc.Driver");
	
		Connection c=DriverManager.getConnection("jdbc:mysql://"+host+":"+port+"/credential","root","September@6");
		Statement s=c.createStatement();
		ResultSet rs=s.executeQuery("select * from logininfo");
		while(rs.next()) {
			driver=launchqaacademy();
			
			
			handlepopup();
			logindbdata().click();
			String username=rs.getString("Name");
			String password=rs.getString("Password");
			Thread.sleep(3000);
			driver.findElement(user).sendKeys(username);;
			driver.findElement(pwd).sendKeys(password);
			driver.findElement(submitbtn).click();
			driver.quit();
		}
		
	}
	
}
