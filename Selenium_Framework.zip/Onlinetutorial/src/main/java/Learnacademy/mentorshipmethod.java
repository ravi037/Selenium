package Learnacademy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class mentorshipmethod {
	
public WebDriver driver;
private	By mentorship=By.xpath("//div[@class='nav-outer clearfix']//a[contains(text(),'Mentorship')]");
private	By join=By.xpath("//div[@class='pricing-container bronze-color pricing-container-flex text-center clearfix col-lg-12 col-md-4 col-sm-6 col-xs-12']//span[@class='h-7'][contains(text(),'JOIN NOW')]");
private	By submit=By.cssSelector("button[id='form-submit']");
	
public WebDriver url() {
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.manage().window().maximize();
	return driver;
	
}
	public void mentorpagenavigate() {
		driver.findElement(mentorship).click();
	}
	
	public void joinow() {
		driver.findElement(join).click();
	}
	public void send() {
		driver.findElement(submit).click();
	}
}
	