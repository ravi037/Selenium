package Resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;

public class Initialization {
	
public WebDriver driver;
	//private	By home=By.linkText("Home");
	//private By course=By.linkText("Courses");
	//private	By projects=By.linkText("Practice Projects");
	//private	By login=By.cssSelector("a[class*=' register-btn']");
	
	
public WebDriver homepagenavigate() throws IOException {
	Properties prop=new Properties();
	FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+ "\\src\\main\\java\\Resources\\Data.properties");
	prop.load(fis);
	
	//String browsername=System.getProperty("browser");  --For passing parameter through Maven command
	//String browsername=prop.getProperty("browser");
	String url=prop.getProperty("url");
	
	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\chromedriver.exe");
	/* driver=new ChromeDriver();
	driver.get(url);
	
	if (browsername.contains("chrome")) {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		//ChromeOptions options=new ChromeOptions();
		if(browsername.contains("headless")) {
			options.addArguments("headless");
		}
		driver=new ChromeDriver(options);
		driver.get(url);
	}
	else if(browsername.equals("IE")) {
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\src\\main\\java\\resources\\IEDriverServer.exe");
		driver=new InternetExplorerDriver();
	}
	else {
		System.out.println("Driver not found");
	} */
	driver.manage().window().maximize();
	return driver;
}

// Capture screenshots on test failure
public String verifyprojectstab(String testcasename, WebDriver driver) throws IOException {
		TakesScreenshot ts=(TakesScreenshot) driver;
				File src=ts.getScreenshotAs(OutputType.FILE);
		String destinationfile=System.getProperty("user.dir")+ "//reports//" +testcasename+ ".png";
		FileUtils.copyFile (src, new File(destinationfile));
		return destinationfile;
	}


}