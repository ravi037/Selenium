package Learnacademy;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Resources.ExtentReporting;
import Resources.Initialization;

public class DBValidation extends ExtentReporting {
	public WebDriver driver;
	@Test
	public void dbvalidations() throws SQLException, InterruptedException, IOException, ClassNotFoundException  {
		Database d=new Database(driver);
		d.dbdata();



	} 	
}
