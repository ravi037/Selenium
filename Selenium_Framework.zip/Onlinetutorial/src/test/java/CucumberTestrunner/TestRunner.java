package CucumberTestrunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		features="C:\\Users\\shriv\\eclipse-workspace\\Onlinetutorial\\src\\test\\java\\Feature",
		glue="StepDefinationCode"
)

public class TestRunner extends AbstractTestNGCucumberTests {


}
