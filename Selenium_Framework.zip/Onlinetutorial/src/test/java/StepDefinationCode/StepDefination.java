package StepDefinationCode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;

import Resources.Initialization;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
public class StepDefination extends Learnacademy.mentorshipmethod {
	By user=By.xpath("//input[@name='name']");
	By id=By.xpath("//input[@name='email']");
	By phone=By.cssSelector("input[name='mobile']");
	
	public static Logger log=LogManager.getLogger(Initialization.class.getName());
	
	@Given("^Land on RahulShettyAcademy \"([^\"]*)\"$")
	    public void land_on_rahulshettyacademy_something(String strArg1) {
		   driver=url();
			driver.get(strArg1);
			log.info("login to Rahul Shetty Academy");
	   }
	
	   @And("^Navigate to Mentorship tab$")
	    public void navigate_to_mentorship_tab() throws InterruptedException {
		   mentorpagenavigate();
		   log.info("User navigated to mentorship page");
	   }
	   
	   @When("^Click on join now$")
	    public void click_on_join_now() throws InterruptedException {
		   joinow();
		   log.info("Navigated to Request for mentorship page");
	   }
	   
	   @Then("^Enter the details (.+) and (.+) and click on submit$")
	    public void enter_the_details_and_and_click_on_submit(String username, String email) throws InterruptedException {
		   driver.findElement(user).sendKeys(username);
		   driver.findElement(id).sendKeys(email);
		   log.info("User name and email-id entered");
	   }
	   
	   @And("^Enter phone number (.+)$")
	    public void enter_phone_number(String phonenumber) throws InterruptedException {
		  
		   driver.findElement(phone).sendKeys(phonenumber);
		   log.info("phone number entered");
	   }
	   
	   @And("^Submit details$")
	    public void submit_details() throws InterruptedException {
		
		   send();
		   log.info("User details submitted");
	   }
	
	    @And("^Close browsers$")
	    public void close_browsers() {
		driver.quit();
	}
}